﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports TamagotchiVBSys
Imports TamagotchiVBSys.DataAccess
<TestClass()> Public Class UnitTest1

    <TestMethod()> Public Sub TestMockData()

        'Check That Database exist and have connection to the Xml data
        Dim dsxml = GetActionsState()
        Assert.IsTrue(dsxml.Tables(0).Rows.Count >= 0)

        'Check that Mockup data exist
        Dim dsEvents = GetActionEvents("Food")
        Assert.IsTrue(dsEvents.Tables(0).Rows.Count >= 0)

    End Sub

End Class