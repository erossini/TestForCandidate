﻿
Imports System.Data.OleDb
Imports System.Xml
Imports System.Reflection
Imports System.IO

Public Class DataAccess

#Region "Live Data"
    Public Shared Function ReadData(tablename As String, WhereString As String) As DataSet
        Dim ds As New DataSet

        Dim olecomm As OleDbCommand
        Dim oleadpt As OleDbDataAdapter
        Dim olecon As New OleDbConnection

        Try
            olecon.ConnectionString = GlobalVariables.ConnectionString
            olecomm = New OleDbCommand

            olecomm.CommandText = " Select * " &
                                   " from " & tablename & " " &
                                   " " & WhereString & " "

            olecomm.Connection = olecon
            olecon.Open()
            oleadpt = New OleDbDataAdapter(olecomm)
            oleadpt.Fill(ds, tablename)

        Catch ex As Exception
            GlobalVariables.msg = "Restart Tamagotchi!"
        Finally
            olecon.Close()
        End Try

        Return ds
    End Function

    Public Shared Function SaveData(tablename As String, fieldname As String, fieldvalue As Double, wherestring As String) As Boolean
        Dim res As Boolean = False
        'Check record state Insert or Update
        Dim olecomm As OleDbCommand
        Dim olecon As New OleDbConnection

        Try
            olecon.ConnectionString = GlobalVariables.ConnectionString
            olecomm = New OleDbCommand

            olecomm.CommandText = " Update " &
                                   " " & tablename & " " &
                                   " Set " & fieldname & " = " & fieldvalue & " " &
                                   " " & wherestring & " "

            olecomm.Connection = olecon
            olecon.Open()
            olecomm.ExecuteNonQuery()

        Catch ex As Exception
            GlobalVariables.msg = "Restart Tamagotchi!"
        Finally
            olecon.Close()
        End Try

        Return res
    End Function
#End Region

#Region "MockUp Data"

    'Get Tamagotchi Statistics (Keep values in xml file)
    Public Shared Function ReadXMLData() As DataSet

        Dim ds As New DataSet
        ds.ReadXml(GlobalVariables.XmlFilePath)
        Return ds

    End Function
    'Save Tamagotchi Statistics Xml file
    Public Shared Function SaveXmlTamagotchi(Fieldname As String, FieldValue As String) As Boolean
        Dim res As Boolean = False

        Try

            Dim xmldoc As New XmlDocument()
            xmldoc.Load(GlobalVariables.XmlFilePath)

            For Each tempNode As XmlNode In xmldoc.DocumentElement
                If tempNode.Name = Fieldname Then
                    tempNode.InnerText = FieldValue
                End If
            Next

            xmldoc.Save(GlobalVariables.XmlFilePath)
            res = True
        Catch ex As Exception
            res = False
        End Try

        Return res
    End Function

    Public Shared Function GetActionsState() As DataSet

        'Get Actions State By level--> Range value and message
        Dim ds As New DataSet
        ds = New DataSet
        ds.Tables.Add("ActionsState")
        ds.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds.Tables(0).Columns.Add("Level", GetType(System.Int32))
        ds.Tables(0).Columns.Add("FromValue", GetType(System.Int32))
        ds.Tables(0).Columns.Add("ToValue", GetType(System.Int32))
        ds.Tables(0).Columns.Add("State", GetType(System.String))

        'Action Food (Humgriness)
        'Level 1
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 0, 10, "Starving"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 11, 30, "Very Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 31, 60, "Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 61, 90, "Almost full"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 91, 100, "I am full"})
        'Level 2
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 0, 20, "Starving"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 21, 30, "Very Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 31, 50, "Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 51, 70, "Almost full"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 71, 100, "I am full"})
        'Level 3
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 0, 20, "Starving"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 21, 30, "Very Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 31, 40, "Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 41, 60, "Almost full"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 61, 100, "I am full"})
        'Level 4
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 0, 25, "Starving"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 26, 35, "Very Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 36, 45, "Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 46, 65, "Almost full"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 66, 100, "I am full"})
        'Level 5
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 0, 25, "Starving"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 26, 30, "Very Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 31, 45, "Hungry"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 46, 75, "Almost full"})
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 76, 100, "I am full"})

        'Action Game (Happiness)
        'Level 1
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 0, 10, "Very Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 11, 30, "Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 31, 60, "Lets Play"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 61, 90, "Happy"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 91, 100, "Very Happy"})
        'Level 2
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 0, 20, "Very Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 21, 30, "Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 31, 50, "Lets Play"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 51, 70, "Happy"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 71, 100, "Very Happy"})
        'Level 3
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 0, 20, "Very Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 21, 30, "Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 31, 40, "Lets Play"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 41, 60, "Happy"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 61, 100, "Very Happy"})
        'Level 4
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 0, 25, "Very Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 26, 35, "Sady"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 36, 45, "Lets Play"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 46, 65, "Happy"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 66, 100, "Very Happy"})
        'Level 5
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 0, 25, "Very Sad"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 26, 30, "Sady"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 31, 45, "Lets Play"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 46, 75, "Happy"})
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 76, 100, "Very Happy"})

        'Action Sleep (Tiretness)
        'Level 1
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 0, 10, "Very Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 11, 30, "Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 31, 60, "Lets Sleep"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 61, 90, "Energy"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 91, 100, "Full Energy"})
        'Level 2
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 0, 20, "Very Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 21, 30, "Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 31, 50, "Lets Sleep"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 51, 70, "Energy"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 71, 100, "Full Energy"})
        'Level 3
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 0, 20, "Very Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 21, 30, "Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 31, 40, "Lets Sleep"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 41, 60, "Energy"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 61, 100, "Full Energy"})
        'Level 4
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 0, 25, "Very Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 26, 35, "Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 36, 45, "Lets Sleep"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 46, 65, "Energy"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 66, 100, "Full Energy"})
        'Level 5
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 0, 25, "Very Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 26, 30, "Tired"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 31, 45, "Lets Sleep"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 46, 75, "Energy"})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 76, 100, "Full Energy"})

        'Action Toilet (Fulness)
        'Level 1
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 1, 0, 10, "Hi Hi Hi"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 1, 11, 30, "Mmmmm"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 1, 31, 60, "Toilet"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 1, 61, 90, "Sick"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 1, 91, 100, "Very Sick"})
        'Level 2
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 2, 0, 20, "Hi Hi Hi"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 2, 21, 30, "Mmmmm"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 2, 31, 50, "Toilet"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 2, 51, 70, "Sick"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 2, 71, 100, "Very Sick"})
        'Level 3
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 3, 0, 20, "Hi Hi Hi"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 3, 21, 30, "Mmmmm"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 3, 31, 40, "Toilet"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 3, 41, 60, "Sick"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 3, 61, 100, "Very Sick"})
        'Level 4
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 4, 0, 25, "Hi Hi Hi"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 4, 26, 35, "Mmmmm"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 4, 36, 45, "Toilet"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 4, 46, 65, "Sick"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 4, 66, 100, "Very Sick"})
        'Level 5
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 5, 0, 25, "Hi Hi Hi"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 5, 26, 30, "Mmmmm"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 5, 31, 45, "Toilet"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 5, 46, 75, "Sick"})
        ds.Tables(0).Rows.Add(New Object() {"Toilet", 5, 76, 100, "Very Sick"})

        Return ds
    End Function

    Public Shared Function GetAgeLevels() As DataSet

        'Get Level by Age range: Age Range --> Level
        Dim ds As New DataSet
        ds = New DataSet
        ds.Tables.Add("AgeLevels")
        ds.Tables(0).Columns.Add("FromAge", GetType(System.Int32))
        ds.Tables(0).Columns.Add("ToAge", GetType(System.Int32))
        ds.Tables(0).Columns.Add("Level", GetType(System.Int32))

        ds.Tables(0).Rows.Add(New Object() {0, 5, 1})
        ds.Tables(0).Rows.Add(New Object() {6, 11, 2})
        ds.Tables(0).Rows.Add(New Object() {12, 16, 3})
        ds.Tables(0).Rows.Add(New Object() {17, 22, 4})
        ds.Tables(0).Rows.Add(New Object() {23, 100, 5})


        Return ds
    End Function

    Public Shared Function GetActionEvents(Action As String) As DataSet

        Dim ds As New DataSet

        'Get Events Values: Action, Event--> Event value Subaction value
        Dim ds1 As New DataSet
        ds1 = New DataSet
        ds1.Tables.Add("FoodActionEvents")
        ds1.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds1.Tables(0).Columns.Add("EventName", GetType(System.String))
        ds1.Tables(0).Columns.Add("EventValue", GetType(System.Int32))
        ds1.Tables(0).Columns.Add("SubActionName", GetType(System.String))
        ds1.Tables(0).Columns.Add("SubActionValue", GetType(System.Int32))
        ds1.Tables(0).Columns.Add("Message", GetType(System.String))

        Dim ds2 As New DataSet
        ds2 = New DataSet
        ds2.Tables.Add("GameActionEvents")
        ds2.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds2.Tables(0).Columns.Add("EventName", GetType(System.String))
        ds2.Tables(0).Columns.Add("EventValue", GetType(System.Int32))
        ds2.Tables(0).Columns.Add("SubActionName", GetType(System.String))
        ds2.Tables(0).Columns.Add("SubActionValue", GetType(System.Int32))
        ds2.Tables(0).Columns.Add("Message", GetType(System.String))

        Dim ds3 As New DataSet
        ds3 = New DataSet
        ds3.Tables.Add("SleepActionEvents")
        ds3.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds3.Tables(0).Columns.Add("EventName", GetType(System.String))
        ds3.Tables(0).Columns.Add("EventValue", GetType(System.Int32))
        ds3.Tables(0).Columns.Add("SubActionName", GetType(System.String))
        ds3.Tables(0).Columns.Add("SubActionValue", GetType(System.Int32))
        ds3.Tables(0).Columns.Add("Message", GetType(System.String))

        Dim ds4 As New DataSet
        ds4 = New DataSet
        ds4.Tables.Add("ToiletActionEvents")
        ds4.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds4.Tables(0).Columns.Add("EventName", GetType(System.String))
        ds4.Tables(0).Columns.Add("EventValue", GetType(System.Int32))
        ds4.Tables(0).Columns.Add("SubActionName", GetType(System.String))
        ds4.Tables(0).Columns.Add("SubActionValue", GetType(System.Int32))
        ds4.Tables(0).Columns.Add("Message", GetType(System.String))

        ds1.Tables(0).Rows.Add(New Object() {"Food", "Apple", 3, "Toilet", 2, "Mmm Fruit"})
        ds1.Tables(0).Rows.Add(New Object() {"Food", "Sandwich", 4, "Toilet", 3, "Nice Sandwich"})
        ds2.Tables(0).Rows.Add(New Object() {"Game", "Run", 3, "Sleep", 2, "Like Running"})
        ds2.Tables(0).Rows.Add(New Object() {"Game", "Football", 4, "Sleep", 3, "Goal"})
        ds3.Tables(0).Rows.Add(New Object() {"Sleep", "Bed", 4, "Sleep", 0, "Zzzzz"})
        ds3.Tables(0).Rows.Add(New Object() {"Sleep", "Relax", 3, "Sleep", 0, "Relax"})
        ds4.Tables(0).Rows.Add(New Object() {"Toilet", "Toilet", 4, "Toilet", 0, "Hi Hi Hi"})
        ds4.Tables(0).Rows.Add(New Object() {"Toilet", "Clean", 3, "Toilet", 0, "Clean"})

        Select Case Action
            Case "Food"
                ds = ds1
            Case "Game"
                ds = ds2
            Case "Sleep"
                ds = ds3
            Case "Toilet"
                ds = ds4
        End Select

        Return ds
    End Function

    Public Shared Function GetActionsTimer() As DataSet

        'Get Action Values on Timer (Online): Level--> Action Values
        Dim ds As New DataSet
        ds = New DataSet
        ds.Tables.Add("ActionTimer")
        ds.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds.Tables(0).Columns.Add("Level", GetType(System.Int32))
        ds.Tables(0).Columns.Add("LiveActionValue", GetType(System.Int32))
        ds.Tables(0).Columns.Add("OffLineActionValue", GetType(System.Int32))


        'Level 1
        ds.Tables(0).Rows.Add(New Object() {"Food", 1, 4, 3})
        ds.Tables(0).Rows.Add(New Object() {"Game", 1, 3, 2})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 1, 4, 3})
        'Level 2
        ds.Tables(0).Rows.Add(New Object() {"Food", 2, 5, 4})
        ds.Tables(0).Rows.Add(New Object() {"Game", 2, 4, 3})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 2, 3, 2})
        'Level 3
        ds.Tables(0).Rows.Add(New Object() {"Food", 3, 6, 5})
        ds.Tables(0).Rows.Add(New Object() {"Game", 3, 5, 4})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 3, 4, 3})
        'Level 4
        ds.Tables(0).Rows.Add(New Object() {"Food", 4, 5, 6})
        ds.Tables(0).Rows.Add(New Object() {"Game", 4, 6, 5})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 4, 7, 4})
        'Level 5
        ds.Tables(0).Rows.Add(New Object() {"Food", 5, 5, 6})
        ds.Tables(0).Rows.Add(New Object() {"Game", 5, 6, 5})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", 5, 7, 4})

        Return ds
    End Function

    Public Shared Function GetShopEvents() As DataSet

        'Get Shop Events: Kablamo--> Events
        Dim ds As New DataSet
        ds = New DataSet
        ds.Tables.Add("ShopEvents")
        ds.Tables(0).Columns.Add("ActionName", GetType(System.String))
        ds.Tables(0).Columns.Add("EventName", GetType(System.String))
        ds.Tables(0).Columns.Add("EventAmount", GetType(System.Int32))


        ds.Tables(0).Rows.Add(New Object() {"Food", "Hamburger", 10})
        ds.Tables(0).Rows.Add(New Object() {"Food", "Chocolate", 4})
        ds.Tables(0).Rows.Add(New Object() {"Game", "Puzzle", 10})
        ds.Tables(0).Rows.Add(New Object() {"Game", "PSP", 40})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", "Big Bed", 30})
        ds.Tables(0).Rows.Add(New Object() {"Sleep", "King Bed", 80})
        Return ds
    End Function

#End Region
    Public Shared Function GetFieldvalue(dst As DataSet, selectvalue As String, wherestring As String) As String
        Dim res As String = "0"
        Dim arr = dst.Tables(0).Select(wherestring)
        For Each row As DataRow In arr
            With row
                If Not IsDBNull(.Item(selectvalue)) Then
                    res = .Item(selectvalue)
                End If
            End With
        Next
        Return res
    End Function

End Class
