﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTamagotchi
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.tdbgShop = New System.Windows.Forms.DataGridView()
        Me.tdbgEvents = New System.Windows.Forms.DataGridView()
        Me.lblTamaMsg = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblFood = New System.Windows.Forms.Label()
        Me.lblgame = New System.Windows.Forms.Label()
        Me.lblSleep = New System.Windows.Forms.Label()
        Me.lblToilet = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCoins = New System.Windows.Forms.Label()
        Me.txtAlerts = New System.Windows.Forms.Label()
        Me.lblToiletState = New System.Windows.Forms.Label()
        Me.lblSleepState = New System.Windows.Forms.Label()
        Me.lblGameState = New System.Windows.Forms.Label()
        Me.lblFoodState = New System.Windows.Forms.Label()
        Me.cmdSave = New System.Windows.Forms.PictureBox()
        Me.cmdexit = New System.Windows.Forms.PictureBox()
        Me.cmdReset = New System.Windows.Forms.PictureBox()
        Me.cmdRes = New System.Windows.Forms.PictureBox()
        Me.cmdShop = New System.Windows.Forms.PictureBox()
        Me.cmdToilet = New System.Windows.Forms.PictureBox()
        Me.cmdSleep = New System.Windows.Forms.PictureBox()
        Me.cmdGame = New System.Windows.Forms.PictureBox()
        Me.cmdFood = New System.Windows.Forms.PictureBox()
        Me.PicTama = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.tdbgShop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbgEvents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdexit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdReset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdRes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdShop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdToilet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdSleep, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdGame, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmdFood, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicTama, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightCyan
        Me.Panel1.Controls.Add(Me.tdbgShop)
        Me.Panel1.Controls.Add(Me.tdbgEvents)
        Me.Panel1.Controls.Add(Me.lblTamaMsg)
        Me.Panel1.Controls.Add(Me.PicTama)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(100, 135)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(400, 365)
        Me.Panel1.TabIndex = 1
        '
        'tdbgShop
        '
        Me.tdbgShop.AllowUserToAddRows = False
        Me.tdbgShop.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgShop.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.tdbgShop.BackgroundColor = System.Drawing.Color.LightCyan
        Me.tdbgShop.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tdbgShop.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbgShop.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.tdbgShop.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdbgShop.ColumnHeadersVisible = False
        Me.tdbgShop.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Monotype Corsiva", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.tdbgShop.DefaultCellStyle = DataGridViewCellStyle3
        Me.tdbgShop.GridColor = System.Drawing.Color.LightCyan
        Me.tdbgShop.Location = New System.Drawing.Point(5, 5)
        Me.tdbgShop.Name = "tdbgShop"
        Me.tdbgShop.ReadOnly = True
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbgShop.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.tdbgShop.RowHeadersVisible = False
        Me.tdbgShop.RowHeadersWidth = 51
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgShop.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.tdbgShop.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.tdbgShop.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.LightCyan
        Me.tdbgShop.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgShop.RowTemplate.Height = 24
        Me.tdbgShop.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tdbgShop.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdbgShop.Size = New System.Drawing.Size(390, 187)
        Me.tdbgShop.TabIndex = 18
        Me.tdbgShop.Visible = False
        '
        'tdbgEvents
        '
        Me.tdbgEvents.AllowUserToAddRows = False
        Me.tdbgEvents.AllowUserToDeleteRows = False
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgEvents.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.tdbgEvents.BackgroundColor = System.Drawing.Color.LightCyan
        Me.tdbgEvents.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tdbgEvents.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbgEvents.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.tdbgEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdbgEvents.ColumnHeadersVisible = False
        Me.tdbgEvents.Cursor = System.Windows.Forms.Cursors.Hand
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Monotype Corsiva", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.tdbgEvents.DefaultCellStyle = DataGridViewCellStyle8
        Me.tdbgEvents.GridColor = System.Drawing.Color.LightCyan
        Me.tdbgEvents.Location = New System.Drawing.Point(5, 3)
        Me.tdbgEvents.Name = "tdbgEvents"
        Me.tdbgEvents.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.tdbgEvents.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.tdbgEvents.RowHeadersVisible = False
        Me.tdbgEvents.RowHeadersWidth = 51
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.LightCyan
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgEvents.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.tdbgEvents.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.tdbgEvents.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.LightCyan
        Me.tdbgEvents.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tdbgEvents.RowTemplate.Height = 24
        Me.tdbgEvents.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tdbgEvents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdbgEvents.Size = New System.Drawing.Size(390, 187)
        Me.tdbgEvents.TabIndex = 17
        Me.tdbgEvents.Visible = False
        '
        'lblTamaMsg
        '
        Me.lblTamaMsg.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTamaMsg.Location = New System.Drawing.Point(34, 213)
        Me.lblTamaMsg.Name = "lblTamaMsg"
        Me.lblTamaMsg.Size = New System.Drawing.Size(347, 24)
        Me.lblTamaMsg.TabIndex = 15
        Me.lblTamaMsg.Text = "Hello My Friend"
        Me.lblTamaMsg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(97, 506)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 24)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(416, 506)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 24)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Age:"
        '
        'txtName
        '
        Me.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtName.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(164, 506)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(198, 23)
        Me.txtName.TabIndex = 10
        Me.txtName.Text = "Tama Name"
        '
        'lblAge
        '
        Me.lblAge.AutoSize = True
        Me.lblAge.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAge.Location = New System.Drawing.Point(479, 506)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(20, 24)
        Me.lblAge.TabIndex = 11
        Me.lblAge.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(2, 351)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 24)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Kablammo"
        '
        'lblFood
        '
        Me.lblFood.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFood.Location = New System.Drawing.Point(89, 65)
        Me.lblFood.Name = "lblFood"
        Me.lblFood.Size = New System.Drawing.Size(69, 24)
        Me.lblFood.TabIndex = 19
        Me.lblFood.Text = "0%"
        Me.lblFood.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblgame
        '
        Me.lblgame.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgame.Location = New System.Drawing.Point(202, 65)
        Me.lblgame.Name = "lblgame"
        Me.lblgame.Size = New System.Drawing.Size(86, 30)
        Me.lblgame.TabIndex = 20
        Me.lblgame.Text = "0%"
        Me.lblgame.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSleep
        '
        Me.lblSleep.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSleep.Location = New System.Drawing.Point(315, 65)
        Me.lblSleep.Name = "lblSleep"
        Me.lblSleep.Size = New System.Drawing.Size(86, 30)
        Me.lblSleep.TabIndex = 21
        Me.lblSleep.Text = "0%"
        Me.lblSleep.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblToilet
        '
        Me.lblToilet.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToilet.Location = New System.Drawing.Point(430, 65)
        Me.lblToilet.Name = "lblToilet"
        Me.lblToilet.Size = New System.Drawing.Size(86, 30)
        Me.lblToilet.TabIndex = 22
        Me.lblToilet.Text = "0%"
        Me.lblToilet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(506, 351)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 24)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Alerts"
        '
        'txtCoins
        '
        Me.txtCoins.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCoins.Location = New System.Drawing.Point(14, 387)
        Me.txtCoins.Name = "txtCoins"
        Me.txtCoins.Size = New System.Drawing.Size(80, 31)
        Me.txtCoins.TabIndex = 24
        Me.txtCoins.Text = "0"
        Me.txtCoins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtAlerts
        '
        Me.txtAlerts.Font = New System.Drawing.Font("Monotype Corsiva", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAlerts.Location = New System.Drawing.Point(502, 387)
        Me.txtAlerts.Name = "txtAlerts"
        Me.txtAlerts.Size = New System.Drawing.Size(80, 31)
        Me.txtAlerts.TabIndex = 25
        Me.txtAlerts.Text = "0"
        Me.txtAlerts.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblToiletState
        '
        Me.lblToiletState.Font = New System.Drawing.Font("Monotype Corsiva", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToiletState.Location = New System.Drawing.Point(430, 95)
        Me.lblToiletState.Name = "lblToiletState"
        Me.lblToiletState.Size = New System.Drawing.Size(86, 37)
        Me.lblToiletState.TabIndex = 29
        Me.lblToiletState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSleepState
        '
        Me.lblSleepState.Font = New System.Drawing.Font("Monotype Corsiva", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSleepState.Location = New System.Drawing.Point(315, 95)
        Me.lblSleepState.Name = "lblSleepState"
        Me.lblSleepState.Size = New System.Drawing.Size(86, 37)
        Me.lblSleepState.TabIndex = 28
        Me.lblSleepState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGameState
        '
        Me.lblGameState.Font = New System.Drawing.Font("Monotype Corsiva", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGameState.Location = New System.Drawing.Point(202, 95)
        Me.lblGameState.Name = "lblGameState"
        Me.lblGameState.Size = New System.Drawing.Size(86, 37)
        Me.lblGameState.TabIndex = 27
        Me.lblGameState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblFoodState
        '
        Me.lblFoodState.Font = New System.Drawing.Font("Monotype Corsiva", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFoodState.Location = New System.Drawing.Point(89, 95)
        Me.lblFoodState.Name = "lblFoodState"
        Me.lblFoodState.Size = New System.Drawing.Size(86, 37)
        Me.lblFoodState.TabIndex = 30
        Me.lblFoodState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdSave
        '
        Me.cmdSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdSave.Enabled = False
        Me.cmdSave.Image = Global.TamagotchiVBSys.My.Resources.Resources.save2
        Me.cmdSave.Location = New System.Drawing.Point(272, 535)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(50, 51)
        Me.cmdSave.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdSave.TabIndex = 18
        Me.cmdSave.TabStop = False
        Me.cmdSave.Tag = "Save"
        '
        'cmdexit
        '
        Me.cmdexit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdexit.Image = Global.TamagotchiVBSys.My.Resources.Resources.exit2
        Me.cmdexit.Location = New System.Drawing.Point(449, 536)
        Me.cmdexit.Name = "cmdexit"
        Me.cmdexit.Size = New System.Drawing.Size(50, 50)
        Me.cmdexit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdexit.TabIndex = 17
        Me.cmdexit.TabStop = False
        Me.cmdexit.Tag = "Exit"
        '
        'cmdReset
        '
        Me.cmdReset.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdReset.Enabled = False
        Me.cmdReset.Image = Global.TamagotchiVBSys.My.Resources.Resources.reset1
        Me.cmdReset.Location = New System.Drawing.Point(100, 536)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.Size = New System.Drawing.Size(50, 50)
        Me.cmdReset.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdReset.TabIndex = 16
        Me.cmdReset.TabStop = False
        Me.cmdReset.Tag = "Reset"
        '
        'cmdRes
        '
        Me.cmdRes.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdRes.Image = Global.TamagotchiVBSys.My.Resources.Resources.Res
        Me.cmdRes.Location = New System.Drawing.Point(506, 226)
        Me.cmdRes.Name = "cmdRes"
        Me.cmdRes.Size = New System.Drawing.Size(80, 80)
        Me.cmdRes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdRes.TabIndex = 7
        Me.cmdRes.TabStop = False
        Me.cmdRes.Tag = "Food"
        '
        'cmdShop
        '
        Me.cmdShop.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdShop.Image = Global.TamagotchiVBSys.My.Resources.Resources.shop
        Me.cmdShop.Location = New System.Drawing.Point(14, 226)
        Me.cmdShop.Name = "cmdShop"
        Me.cmdShop.Size = New System.Drawing.Size(80, 80)
        Me.cmdShop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdShop.TabIndex = 6
        Me.cmdShop.TabStop = False
        Me.cmdShop.Tag = "Shop"
        '
        'cmdToilet
        '
        Me.cmdToilet.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdToilet.Image = Global.TamagotchiVBSys.My.Resources.Resources.Wc
        Me.cmdToilet.Location = New System.Drawing.Point(450, 12)
        Me.cmdToilet.Name = "cmdToilet"
        Me.cmdToilet.Size = New System.Drawing.Size(50, 50)
        Me.cmdToilet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdToilet.TabIndex = 5
        Me.cmdToilet.TabStop = False
        Me.cmdToilet.Tag = "Toilet"
        '
        'cmdSleep
        '
        Me.cmdSleep.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdSleep.Image = Global.TamagotchiVBSys.My.Resources.Resources.Sleep
        Me.cmdSleep.Location = New System.Drawing.Point(333, 12)
        Me.cmdSleep.Name = "cmdSleep"
        Me.cmdSleep.Size = New System.Drawing.Size(50, 50)
        Me.cmdSleep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdSleep.TabIndex = 4
        Me.cmdSleep.TabStop = False
        Me.cmdSleep.Tag = "Sleep"
        '
        'cmdGame
        '
        Me.cmdGame.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdGame.Image = Global.TamagotchiVBSys.My.Resources.Resources.Game
        Me.cmdGame.Location = New System.Drawing.Point(221, 12)
        Me.cmdGame.Name = "cmdGame"
        Me.cmdGame.Size = New System.Drawing.Size(50, 50)
        Me.cmdGame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdGame.TabIndex = 3
        Me.cmdGame.TabStop = False
        Me.cmdGame.Tag = "Game"
        '
        'cmdFood
        '
        Me.cmdFood.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdFood.Image = Global.TamagotchiVBSys.My.Resources.Resources.Food
        Me.cmdFood.Location = New System.Drawing.Point(100, 12)
        Me.cmdFood.Name = "cmdFood"
        Me.cmdFood.Size = New System.Drawing.Size(50, 50)
        Me.cmdFood.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.cmdFood.TabIndex = 2
        Me.cmdFood.TabStop = False
        Me.cmdFood.Tag = "Food"
        '
        'PicTama
        '
        Me.PicTama.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicTama.Image = Global.TamagotchiVBSys.My.Resources.Resources.TamaEgg
        Me.PicTama.Location = New System.Drawing.Point(158, 249)
        Me.PicTama.Name = "PicTama"
        Me.PicTama.Size = New System.Drawing.Size(100, 100)
        Me.PicTama.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicTama.TabIndex = 7
        Me.PicTama.TabStop = False
        Me.PicTama.Tag = "Shop"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TamagotchiVBSys.My.Resources.Resources.TamaHeader
        Me.PictureBox1.Location = New System.Drawing.Point(84, 20)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(232, 151)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'frmTamagotchi
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(598, 598)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblFoodState)
        Me.Controls.Add(Me.lblToiletState)
        Me.Controls.Add(Me.lblSleepState)
        Me.Controls.Add(Me.lblGameState)
        Me.Controls.Add(Me.txtAlerts)
        Me.Controls.Add(Me.txtCoins)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblToilet)
        Me.Controls.Add(Me.lblSleep)
        Me.Controls.Add(Me.lblgame)
        Me.Controls.Add(Me.lblFood)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdexit)
        Me.Controls.Add(Me.cmdReset)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblAge)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdRes)
        Me.Controls.Add(Me.cmdShop)
        Me.Controls.Add(Me.cmdToilet)
        Me.Controls.Add(Me.cmdSleep)
        Me.Controls.Add(Me.cmdGame)
        Me.Controls.Add(Me.cmdFood)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmTamagotchi"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        CType(Me.tdbgShop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbgEvents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdexit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdReset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdRes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdShop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdToilet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdSleep, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdGame, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmdFood, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicTama, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents cmdFood As PictureBox
    Friend WithEvents cmdGame As PictureBox
    Friend WithEvents cmdSleep As PictureBox
    Friend WithEvents cmdToilet As PictureBox
    Friend WithEvents cmdShop As PictureBox
    Friend WithEvents cmdRes As PictureBox
    Friend WithEvents PicTama As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblAge As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents cmdReset As PictureBox
    Friend WithEvents cmdexit As PictureBox
    Friend WithEvents cmdSave As PictureBox
    Friend WithEvents lblFood As Label
    Friend WithEvents lblgame As Label
    Friend WithEvents lblSleep As Label
    Friend WithEvents lblToilet As Label
    Friend WithEvents lblTamaMsg As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents tdbgEvents As DataGridView
    Friend WithEvents Label6 As Label
    Friend WithEvents txtCoins As Label
    Friend WithEvents txtAlerts As Label
    Friend WithEvents lblToiletState As Label
    Friend WithEvents lblSleepState As Label
    Friend WithEvents lblGameState As Label
    Friend WithEvents lblFoodState As Label
    Friend WithEvents tdbgShop As DataGridView
End Class
