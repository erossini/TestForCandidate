﻿Public Class GlobalVariables
    Public Shared ConnectionString As String
    Public Shared XmlFilePath As String
    Public Shared msg As String
End Class
