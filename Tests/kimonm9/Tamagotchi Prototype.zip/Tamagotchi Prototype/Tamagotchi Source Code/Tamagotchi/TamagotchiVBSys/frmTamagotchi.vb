﻿Imports System.Net
Imports System.Threading
Imports Timer = System.Timers.Timer
Imports System.Timers
Imports System.ComponentModel


Public Class frmTamagotchi

#Region "Tama Variables"

    Private timer As Timer
    Private bgWorker As New BackgroundWorker
    Private TimerInterval As Integer = 60000
    Private tamaAge As Integer = 0
    Private tamaFood As Double = 0
    Private tamaGame As Double = 0
    Private tamaSleep As Double = 0
    Private tamaToilet As Double = 0
    Private tamaLevel As Integer = 1
    Private OnlineAge As Integer = 2
    Private OffLineAge As Integer = 1
    Private LastExit As DateTime
    Private ActionType As Integer = 0
    Private IsBegin As Integer = 0
    Private dstState As New DataSet
    Private dstActionsState As New DataSet
    Private dstAgeLevels As New DataSet
    Private dstActionEvents As New DataSet
    Private dstActionsTimer As New DataSet
    Private dstShopEvents As New DataSet
    Private IsShop As Integer = 0

#End Region

#Region "BackgroundFunctions"

    Delegate Sub SetLabelText_Delegate(ByVal [Label] As Label, ByVal [text] As String)
    Delegate Sub SetLabelColor_Delegate(ByVal [Label] As Label, ByVal [Color] As Drawing.Color)

    Private Sub SetLabelText_ThreadSafe(ByVal [Label] As Label, ByVal [text] As String)
        ' InvokeRequired required compares the thread ID of the calling thread to the thread ID of the creating thread.
        ' If these threads are different, it returns true.
        If [Label].InvokeRequired Then
            Dim MyDelegate As New SetLabelText_Delegate(AddressOf SetLabelText_ThreadSafe)
            Me.Invoke(MyDelegate, New Object() {[Label], [text]})
        Else
            [Label].Text = [text]
        End If
    End Sub
    Private Sub SetLabelColor_ThreadSafe(ByVal [Label] As Label, ByVal [Color] As Drawing.Color)
        ' InvokeRequired required compares the thread ID of the calling thread to the thread ID of the creating thread.
        ' If these threads are different, it returns true.
        If [Label].InvokeRequired Then
            Dim MyDelegate As New SetLabelColor_Delegate(AddressOf SetLabelColor_ThreadSafe)
            Me.Invoke(MyDelegate, New Object() {[Label], [Color]})
        Else
            [Label].ForeColor = [Color]
        End If
    End Sub
    Private Sub MyWorker_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs)

        'Get Online (Timer) Action Values
        Dim LiveActionValueFood = DataAccess.GetFieldvalue(dstActionsTimer, "LiveActionValue", "ActionName = 'Food' And Level = " & tamaLevel)
        Dim LiveActionValueGame = DataAccess.GetFieldvalue(dstActionsTimer, "LiveActionValue", "ActionName = 'Game' And Level = " & tamaLevel)
        Dim LiveActionValueSleep = DataAccess.GetFieldvalue(dstActionsTimer, "LiveActionValue", "ActionName = 'Sleep' And Level = " & tamaLevel)
        'Dim LiveActionValueToilet = DataAccess.GetFieldvalue(dstActionsTimer, "LiveActionValue", "ActionName = 'Toilet' And Level = " & tamaLevel)

        'Calc Actions Values Online
        CalcFoodActionValuesandColors(1, LiveActionValueFood, 0)
        CalcGameActionValuesandColors(1, LiveActionValueGame, 0)
        CalcSleepActionValuesandColors(1, LiveActionValueSleep, 0)
        'CalcToiletActionValuesandColors(1,LiveActionValueToilet,0)

        'Calc Online Age and Get level
        tamaAge += OnlineAge
        tamaLevel = DataAccess.GetFieldvalue(dstAgeLevels, "Level", "FromAge <= " & tamaAge & " And ToAge >= " & tamaAge)

        'Todo Show Tama Age
        SetLabelText_ThreadSafe(lblAge, tamaAge)

        'Set Tamagotchi Picture by Level (Age) on Line Game
        Select Case tamaLevel
            Case 1
                If Not PicTama.Image Is My.Resources.TamaEgg Then PicTama.Image = My.Resources.TamaEgg
            Case 2
                If Not PicTama.Image Is My.Resources.TamaBaby Then PicTama.Image = My.Resources.TamaBaby
            Case 3
                If Not PicTama.Image Is My.Resources.TamaTeen Then PicTama.Image = My.Resources.TamaTeen
            Case 4
                If Not PicTama.Image Is My.Resources.TamaAdult Then PicTama.Image = My.Resources.TamaAdult
            Case 5
                If Not PicTama.Image Is My.Resources.TamaAdult Then PicTama.Image = My.Resources.TamaAdult
        End Select

        'Update Xml Database keep latest action value to your database
        UpdateActions()

        'Check if Tamagotchi is alive
        TamagotchiRip()

    End Sub
    Private Sub MyWorker_RunWorkerCompleted(ByVal sender As Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs)
        'Add your codes for the worker to execute after finishing the work.
        RemoveHandler bgWorker.DoWork, AddressOf MyWorker_DoWork
        RemoveHandler bgWorker.RunWorkerCompleted, AddressOf MyWorker_RunWorkerCompleted
    End Sub
    Private Sub StartTimer()
        'Setup Timer
        'Dim timer As Timer = New Timer(TimerInterval)
        timer = New Timer(TimerInterval)
        AddHandler timer.Elapsed, New ElapsedEventHandler(AddressOf TimerElapsed)
        timer.Start()
    End Sub
    Private Sub TimerElapsed(ByVal sender As Object, ByVal e As ElapsedEventArgs)

        bgWorker = New BackgroundWorker
        AddHandler bgWorker.DoWork, AddressOf MyWorker_DoWork
        AddHandler bgWorker.RunWorkerCompleted, AddressOf MyWorker_RunWorkerCompleted
        bgWorker.RunWorkerAsync()

    End Sub
#End Region

#Region "Calculate Actions"

    Private Sub CalcFoodActionValuesandColors(ActionType As Integer, RndValue As Integer, subRndValue As Integer)

        Dim r As Random = New Random

        Select Case ActionType
            Case 0 'Offline Timer
                'Hungriness Decreased offline
                tamaFood = tamaFood + (r.Next(1, RndValue) * (-1))
            Case 1 'Online Timer
                'Hungriness Decreased OnLine
                tamaFood = tamaFood + (r.Next(1, RndValue) * (-1))
            Case 2 'Online Action
                'Hungriness Decreased
                tamaFood = tamaFood + (r.Next(1, RndValue))
                'Fulness Increased
                tamaToilet = tamaToilet + (r.Next(1, subRndValue))
        End Select

        'Min Value = 0 - Max Value =100
        CalclMinMaxvalues()
        'Set percentage Value and Color
        SetColorandText(lblFood, tamaFood)
        SetColorandText(lblToilet, tamaToilet)

        'Get State Level,Value --> State
        Dim state1 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Food' And FromValue <= " & tamaFood & " And ToValue >= " & tamaFood & " And Level = " & tamaLevel)
        SetSateColorandText(lblFoodState, tamaFood, state1)
        Dim state2 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Toilet' And FromValue <= " & tamaToilet & " And ToValue >= " & tamaToilet & " And Level = " & tamaLevel)
        SetSateColorandText(lblToiletState, tamaToilet, state2)

        'Check if Tamagotchi is alive
        TamagotchiRip()
    End Sub

    Private Sub CalcGameActionValuesandColors(ActionType As Integer, RndValue As Integer, subRndValue As Integer)

        Dim r As Random = New Random
        '#TODO get rnd values
        'Dim RndValue As Integer = 4
        'Dim ActionValue As Integer = 0

        Select Case ActionType
            Case 0 'Offline Timer
                'Happiness decreased offline
                tamaGame = tamaGame + (r.Next(1, RndValue) * (-1))
            Case 1 'Online Timer
                'Happiness decreased OnLine
                tamaGame = tamaGame + (r.Next(1, RndValue) * (-1))
            Case 2 'Online Action
                'Happiness Increased
                tamaGame = tamaGame + (r.Next(1, RndValue))
                'Tridness decreased
                tamaSleep = tamaSleep + (r.Next(1, subRndValue) * (-1))
        End Select

        'Min Value = 0 - Max Value =100
        CalclMinMaxvalues()
        'Set Action Percentage color and Value
        SetColorandText(lblgame, tamaGame)
        SetColorandText(lblSleep, tamaSleep)

        'Get State Level,Value --> State
        Dim state1 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Game' And FromValue <= " & tamaGame & " And ToValue >= " & tamaGame & " And Level = " & tamaLevel)
        SetSateColorandText(lblGameState, tamaGame, state1)
        Dim state2 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Sleep' And FromValue <= " & tamaSleep & " And ToValue >= " & tamaSleep & " And Level = " & tamaLevel)
        SetSateColorandText(lblSleepState, tamaSleep, state2)

    End Sub
    Private Sub CalcSleepActionValuesandColors(ActionType As Integer, RndValue As Integer, subRndValue As Integer)

        Dim r As Random = New Random
        '#TODO get rnd values
        'Dim RndValue As Integer = 4
        'Dim ActionValue As Integer = 0

        Select Case ActionType
            Case 0 'Offline Timer
                'Tiretness Increased offline
                tamaSleep = tamaSleep + (r.Next(1, RndValue) * (-1))
            Case 1 'Online Timer
                'Tiretness Increased OnLine
                tamaSleep = tamaSleep + (r.Next(1, RndValue) * (-1))
            Case 2 'Online Action
                'Tiretness Increased Decreased
                tamaSleep = tamaSleep + (r.Next(1, RndValue))
                'Fulness Increased
        End Select

        'Min Value = 0 - Max Value =100
        CalclMinMaxvalues()

        'Set Action Value and Color
        SetColorandText(lblSleep, tamaSleep)
        'Get State Level,Value --> State
        Dim state1 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Sleep' And FromValue <= " & tamaSleep & " And ToValue >= " & tamaSleep & " And Level = " & tamaLevel)
        SetSateColorandText(lblSleepState, tamaSleep, state1)

        'Check if Tamagotchi is alive
        TamagotchiRip()

    End Sub

    Private Sub CalclMinMaxvalues()
        If tamaFood > 100 Then tamaFood = 100
        If tamaGame > 100 Then tamaGame = 100
        If tamaSleep > 100 Then tamaSleep = 100
        If tamaToilet > 100 Then tamaToilet = 100
        If tamaFood < 0 Then tamaFood = 0
        If tamaToilet < 0 Then tamaToilet = 0
        If tamaSleep < 0 Then tamaSleep = 0
        If tamaToilet < 0 Then tamaToilet = 0

    End Sub

    Private Sub CalcToiletActionValuesandColors(ActionType As Integer, RndValue As Integer, subRndValue As Integer)

        Dim r As Random = New Random
        '#TODO get rnd values
        'Dim RndValue As Integer = 4
        'Dim ActionValue As Integer = 0

        Select Case ActionType
            Case 0 'Offline Timer
                'No Action Offline Timer
            Case 1 'Online Timer
                'No Action Online Timer
            Case 2 'Online Action
                'fulness Decreased
                tamaToilet = tamaToilet + (r.Next(1, RndValue) * (-1))
                'Fulness Increased
        End Select
        If tamaToilet > 100 Then tamaToilet = 100 : If tamaToilet < 0 Then tamaToilet = 0

        'Set Action Value and Color
        SetColorandText(lblToilet, tamaToilet)
        'Get State Level,Value --> State
        Dim state1 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Toilet' And FromValue <= " & tamaToilet & " And ToValue >= " & tamaToilet & " And Level = " & tamaLevel)
        SetSateColorandText(lblToiletState, tamaToilet, state1)

        'Check if Tamagotchi is alive
        TamagotchiRip()
    End Sub
    Private Sub SetColorandText(ControlValue As Label, ActionValue As Integer)

        'Update Action Value on UI
        SetLabelText_ThreadSafe(ControlValue, ActionValue & "%")

        'Update Action Color on UI
        If ControlValue Is lblToilet Then
            If ActionValue >= 0 And ActionValue <= 35 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Green)
            ElseIf ActionValue >= 36 And ActionValue <= 70 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Blue)
            ElseIf ActionValue >= 71 And ActionValue <= 100 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Red)
            End If
        Else
            If ActionValue >= 0 And ActionValue <= 35 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Red)
            ElseIf ActionValue >= 36 And ActionValue <= 70 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Blue)
            ElseIf ActionValue >= 71 And ActionValue <= 100 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Green)
            End If
        End If


    End Sub

    Private Sub SetSateColorandText(ControlValue As Label, ActionValue As Integer, state As String)

        'Update Action Value on UI
        SetLabelText_ThreadSafe(ControlValue, state)

        'Update Action Color on UI
        If ControlValue Is lblToiletState Then
            If ActionValue >= 0 And ActionValue <= 35 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Green)
            ElseIf ActionValue >= 36 And ActionValue <= 70 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Blue)
            ElseIf ActionValue >= 71 And ActionValue <= 100 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Red)
            End If
        Else
            If ActionValue >= 0 And ActionValue <= 35 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Red)
            ElseIf ActionValue >= 36 And ActionValue <= 70 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Blue)
            ElseIf ActionValue >= 71 And ActionValue <= 100 Then
                SetLabelColor_ThreadSafe(ControlValue, Color.Green)
            End If
        End If
    End Sub
#End Region

    Private Sub frmTamagotchi_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Get Connection String
        GlobalVariables.ConnectionString = System.Configuration.ConfigurationSettings.AppSettings("ConnectionString")
        GlobalVariables.XmlFilePath = System.Configuration.ConfigurationSettings.AppSettings("XmlFilePath")
        TimerInterval = System.Configuration.ConfigurationSettings.AppSettings("TimerInterval")

        'Connet To Database or MockUp Data & Load Tamacotchi Parameters and latest State
        dstState = DataAccess.ReadXMLData()
        dstActionsState = DataAccess.GetActionsState
        dstAgeLevels = DataAccess.GetAgeLevels
        dstActionsTimer = DataAccess.GetActionsTimer
        dstShopEvents = DataAccess.GetShopEvents

        SetTamagotchiState()

        'Start Timer to run BackgroundWorker (All the functions according time pass)
        StartTimer()

        'Check if Is alive
        TamagotchiRip()

    End Sub

    Private Sub SetTamagotchiState()
        'Read Xml and get Tamagotchi State
        dstState.Clear()
        dstState = DataAccess.ReadXMLData()
        'Get Tamagotchi Name-Age-Balance-Last Exit & Action Values
        For Each r1 As DataRow In dstState.Tables(0).Rows
            With r1
                If Not IsDBNull(.Item("Name")) Then Me.txtName.Text = .Item("Name")
                If Not IsDBNull(.Item("Age")) Then Me.lblAge.Text = .Item("Age") : tamaAge = Me.lblAge.Text
                If Not IsDBNull(.Item("Balance")) Then Me.txtCoins.Text = .Item("Balance")
                If Not IsDBNull(.Item("LastGame")) Then LastExit = CDate(.Item("LastGame"))
                If Not IsDBNull(.Item("Food")) Then tamaFood = .Item("Food")
                If Not IsDBNull(.Item("Game")) Then tamaGame = .Item("Game")
                If Not IsDBNull(.Item("Sleep")) Then tamaSleep = .Item("Sleep")
                If Not IsDBNull(.Item("Toilet")) Then tamaToilet = .Item("Toilet")
                If Not IsDBNull(.Item("IsBegin")) Then IsBegin = .Item("IsBegin")
            End With
        Next

        'Enable disable butons 
        If IsBegin = 0 Then cmdSave.Enabled = True : cmdReset.Enabled = False Else cmdSave.Enabled = False : cmdReset.Enabled = True : Me.txtName.Enabled = True

        'Get Tamagotchi Level
        tamaLevel = DataAccess.GetFieldvalue(dstAgeLevels, "Level", "FromAge <= " & tamaAge & " And ToAge >= " & tamaAge)

        'If Is already the game started Isbegin=1
        'If Is Begin = 1 --> get the values for the offline actions calculation: Action,Level--> OfflineActions calculation and multiple per Interval
        'Add the offliineAction Values to Action Values
        'Add the ofline Age values to the Age values.
        'Get The new level of tamagotchi
        '----------- OffLine -------------------------
        If IsBegin = 1 Then

            Dim minutesDiff = DateDiff(DateInterval.Minute, LastExit, Now)
            'Get Online (Timer) Action Values
            Dim OfflineActionValueFood = DataAccess.GetFieldvalue(dstActionsTimer, "OfflineActionValue", "ActionName = 'Food' And Level = " & tamaLevel)
            Dim OfflineActionValueGame = DataAccess.GetFieldvalue(dstActionsTimer, "OfflineActionValue", "ActionName = 'Game' And Level = " & tamaLevel)
            Dim OfflineActionValueSleep = DataAccess.GetFieldvalue(dstActionsTimer, "OfflineActionValue", "ActionName = 'Sleep' And Level = " & tamaLevel)
            'Dim OfflineActionValueToilet = DataAccess.GetFieldvalue(dstActionsTimer, "OfflineActionValue", "ActionName = 'Toilet' And Level = " & tamaLevel)

            'Calc Actions Values Online
            tamaFood += OfflineActionValueFood * minutesDiff * (-1)
            If tamaFood > 100 Then tamaFood = 100
            If tamaFood < 0 Then tamaFood = 0
            tamaGame += OfflineActionValueGame * minutesDiff * (-1)
            If tamaGame > 100 Then tamaGame = 100
            If tamaGame < 0 Then tamaGame = 0
            tamaSleep += OfflineActionValueSleep * minutesDiff * (-1)
            If tamaSleep > 100 Then tamaSleep = 100
            If tamaSleep < 0 Then tamaSleep = 0
            'tamatoilet += OfflineActionValueToilet * minutesDiff
            'Get New Age after start
            tamaAge += OffLineAge * minutesDiff
            Me.lblAge.Text = tamaAge
            'Get new level after Start
            tamaLevel = DataAccess.GetFieldvalue(dstAgeLevels, "Level", "FromAge <= " & tamaAge & " And ToAge >= " & tamaAge)
            Me.txtName.Enabled = False
            Me.txtName.BackColor = Color.White
        End If
        '----------- End of OffLine ------------------


        'Set Action Color and Values
        SetColorandText(lblFood, tamaFood) : SetColorandText(lblgame, tamaGame) : SetColorandText(lblSleep, tamaSleep) : SetColorandText(lblToilet, tamaToilet)

        'Get State Level,Value --> State
        Dim state1 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Game' And FromValue <= " & tamaGame & " And ToValue >= " & tamaGame & " And Level = " & tamaLevel)
        SetSateColorandText(lblGameState, tamaGame, state1)
        Dim state2 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Sleep' And FromValue <= " & tamaSleep & " And ToValue >= " & tamaSleep & " And Level = " & tamaLevel)
        SetSateColorandText(lblSleepState, tamaSleep, state2)
        Dim state3 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Food' And FromValue <= " & tamaFood & " And ToValue >= " & tamaFood & " And Level = " & tamaLevel)
        SetSateColorandText(lblFoodState, tamaFood, state3)
        Dim state4 = DataAccess.GetFieldvalue(dstActionsState, "State", "ActionName = 'Toilet' And FromValue <= " & tamaToilet & " And ToValue >= " & tamaToilet & " And Level = " & tamaLevel)
        SetSateColorandText(lblToiletState, tamaToilet, state4)


        'Set Tamagotchi Picture by Level (Age) on Load Game
        Select Case tamaLevel
            Case 1
                PicTama.Image = My.Resources.TamaEgg
            Case 2
                PicTama.Image = My.Resources.TamaBaby
            Case 3
                PicTama.Image = My.Resources.TamaTeen
            Case 4
                PicTama.Image = My.Resources.TamaAdult
            Case 5
                PicTama.Image = My.Resources.TamaAdult
        End Select
    End Sub
    Private Sub cmdexit_Click(sender As Object, e As EventArgs) Handles cmdexit.Click
        'Save day time & update data before close
        UpdateActions()
        Me.Close()
        End

    End Sub

    Private Sub ActionEventsDisplay(ActionName As String)
        'Get Action Details
        dstActionEvents = DataAccess.GetActionEvents(ActionName)


        tdbgEvents.Width = 390

        With tdbgEvents
            .DataSource = dstActionEvents.Tables(0)
            .Columns(1).HeaderText = "Select Action"
            .Columns(1).Width = 320

            .Columns(1).ReadOnly = True

            .Columns(0).Visible = False
            .Columns(2).Visible = False
            .Columns(3).Visible = False
            .Columns(4).Visible = False
            .Columns(5).Visible = False
            .Visible = True
        End With

    End Sub

    Private Sub ActionButtons_Click(sender As Object, e As EventArgs) Handles cmdFood.Click, cmdGame.Click, cmdToilet.Click, cmdSleep.Click
        Dim btn As System.Windows.Forms.PictureBox = sender
        Dim actionname = btn.Tag
        ActionEventsDisplay(actionname)
        Me.tdbgShop.Visible = False
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        If IsBegin = 0 Then

            'Update Your Tamagotchi Name

            DataAccess.SaveXmlTamagotchi("Name", Me.txtName.Text)
            Me.txtName.Enabled = False
            Me.txtName.BackColor = Color.White
            DataAccess.SaveXmlTamagotchi("IsBegin", 1)
            'DataAccess.SaveXmlTamagotchi("LastGame", Now)

            cmdSave.Enabled = False : cmdReset.Enabled = True

        End If

    End Sub

    Private Sub UpdateActions()

        DataAccess.SaveXmlTamagotchi("Food", tamaFood)
        DataAccess.SaveXmlTamagotchi("Game", tamaGame)
        DataAccess.SaveXmlTamagotchi("Sleep", tamaSleep)
        DataAccess.SaveXmlTamagotchi("Toilet", tamaToilet)
        DataAccess.SaveXmlTamagotchi("Age", tamaAge)
        DataAccess.SaveXmlTamagotchi("LastGame", Now)

    End Sub

    Private Sub cmdReset_Click(sender As Object, e As EventArgs) Handles cmdReset.Click
        DataAccess.SaveXmlTamagotchi("Food", 60)
        DataAccess.SaveXmlTamagotchi("Game", 50)
        DataAccess.SaveXmlTamagotchi("Sleep", 55)
        DataAccess.SaveXmlTamagotchi("Toilet", 45)
        DataAccess.SaveXmlTamagotchi("Name", "")
        DataAccess.SaveXmlTamagotchi("Age", 0)
        DataAccess.SaveXmlTamagotchi("IsBegin", 0)
        Me.txtName.Enabled = True
        Me.lblTamaMsg.Text = "Hello My Friend"
        SetTamagotchiState()
        StartTimer()
    End Sub

    Private Sub tdbgEvents_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles tdbgEvents.CellDoubleClick
        If e.RowIndex = -1 Then
            Return
        End If

        'Get The values for the selected Event for this action and check if raise any othe action
        Dim ActionName As String = ""
            Dim EventValue As Integer = 0
            Dim SubActionName As String = ""
            Dim SubActionValue As Integer = 0
            Dim MessageState As String = ""

            ' Double-click logic.
            If Me.tdbgEvents.Rows(e.RowIndex).Cells("ActionName").Value.ToString.Length > 0 Then
                ActionName = tdbgEvents.Rows(e.RowIndex).Cells("ActionName").Value
            End If

            If Me.tdbgEvents.Rows(e.RowIndex).Cells("EventValue").Value.ToString.Length > 0 Then
                EventValue = tdbgEvents.Rows(e.RowIndex).Cells("EventValue").Value
            End If

            If Me.tdbgEvents.Rows(e.RowIndex).Cells("SubActionName").Value.ToString.Length > 0 Then
                SubActionName = tdbgEvents.Rows(e.RowIndex).Cells("SubActionName").Value
            End If

            If Me.tdbgEvents.Rows(e.RowIndex).Cells("SubActionValue").Value.ToString.Length > 0 Then
                SubActionValue = tdbgEvents.Rows(e.RowIndex).Cells("SubActionValue").Value
            End If

            If Me.tdbgEvents.Rows(e.RowIndex).Cells("Message").Value.ToString.Length > 0 Then
                MessageState = tdbgEvents.Rows(e.RowIndex).Cells("Message").Value
            End If

            'Calc Actions
            Select Case ActionName
                Case "Food"
                    CalcFoodActionValuesandColors(2, EventValue, SubActionValue)
                Case "Game"
                    CalcGameActionValuesandColors(2, EventValue, SubActionValue)
                Case "Sleep"
                    CalcSleepActionValuesandColors(2, EventValue, SubActionValue)
                Case "Toilet"
                    CalcToiletActionValuesandColors(2, EventValue, SubActionValue)
            End Select


            SetSateColorandText(lblTamaMsg, 100, MessageState)

            Me.tdbgEvents.Visible = False
    End Sub

    Private Sub cmdShop_Click(sender As Object, e As EventArgs) Handles cmdShop.Click
        Me.tdbgEvents.Visible = False

        With tdbgShop
            .DataSource = dstShopEvents.Tables(0)
            .Columns(0).HeaderText = "Action"
            .Columns(0).Width = 110
            .Columns(1).HeaderText = "Event"
            .Columns(1).Width = 110
            .Columns(2).HeaderText = "Amount"
            .Columns(2).Width = 110

            .Columns(0).ReadOnly = True
            .Columns(1).ReadOnly = True
            .Columns(2).ReadOnly = True

            .Visible = True
        End With
    End Sub

    Private Sub TamagotchiRip()
        If tamaFood = 0 Or tamaToilet = 100 Or tamaSleep = 0 Then
            RemoveHandler timer.Elapsed, New ElapsedEventHandler(AddressOf TimerElapsed)
            timer.Stop()
            PicTama.Image = My.Resources.RIP
            SetSateColorandText(lblTamaMsg, 0, "R.I.P Please Reset")

        End If
    End Sub

    Private Sub tdbgShop_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles tdbgShop.CellDoubleClick
        If e.RowIndex = -1 Then
            Return
        End If
        Me.tdbgShop.Visible = False
    End Sub
End Class